@rem Execute gradle in root project
@if "%DEBUG%"=="" @echo off
set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
gradle --project-dir "%DIRNAME%" %*
