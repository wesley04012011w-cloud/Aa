package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppScreen
import com.example.ui.ChatNavigationDrawerContent
import com.example.ui.ChatScreen
import com.example.ui.ExplorerScreen
import com.example.ui.ModelsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  private val chatViewModel: ChatViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MainAppContent(viewModel = chatViewModel)
      }
    }
  }
}

@Composable
fun MainAppContent(viewModel: ChatViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  // Handle Android Back button behavior
  BackHandler(enabled = drawerState.isOpen || uiState.currentScreen != AppScreen.CHAT) {
    if (drawerState.isOpen) {
      scope.launch { drawerState.close() }
    } else if (uiState.currentScreen != AppScreen.CHAT) {
      viewModel.navigateTo(AppScreen.CHAT)
    }
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    gesturesEnabled = drawerState.isOpen || uiState.currentScreen == AppScreen.CHAT,
    drawerContent = {
      ChatNavigationDrawerContent(
        uiState = uiState,
        onNavigate = { screen ->
          viewModel.navigateTo(screen)
        },
        onNewChat = {
          viewModel.createNewSession()
        },
        onSelectSession = { sessionId ->
          viewModel.selectSession(sessionId)
        },
        onDeleteSession = { sessionId ->
          viewModel.deleteSession(sessionId)
        },
        onOpenSettings = {
          viewModel.toggleSettingsSheet(true)
        },
        onOpenHardwareInfo = {
          viewModel.toggleHardwareInfoDialog(true)
        },
        onCloseDrawer = {
          scope.launch { drawerState.close() }
        }
      )
    }
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = MaterialTheme.colorScheme.background
    ) {
      when (uiState.currentScreen) {
        AppScreen.CHAT -> {
          ChatScreen(
            viewModel = viewModel,
            onOpenDrawer = {
              scope.launch { drawerState.open() }
            }
          )
        }
        AppScreen.MODELS -> {
          ModelsScreen(
            viewModel = viewModel,
            uiState = uiState
          )
        }
        AppScreen.EXPLORER -> {
          ExplorerScreen(
            viewModel = viewModel,
            uiState = uiState
          )
        }
      }
    }
  }
}
