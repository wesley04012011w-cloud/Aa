package com.example.service

import android.content.Context
import android.net.Uri
import com.example.model.ModelOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

class ModelFileManager(private val context: Context) {

  private val client: OkHttpClient = OkHttpClient.Builder()
    .followRedirects(true)
    .followSslRedirects(true)
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(120, TimeUnit.SECONDS)
    .build()

  val modelsDir: File
    get() {
      val dir = File(context.filesDir, "models")
      if (!dir.exists()) {
        dir.mkdirs()
      }
      return dir
    }

  fun getModelFile(modelId: String): File {
    return File(modelsDir, "$modelId.pte")
  }

  fun isModelDownloaded(modelId: String): Boolean {
    val file = getModelFile(modelId)
    return file.exists() && file.length() > 0
  }

  fun getModelSizeMB(modelId: String): Int {
    val file = getModelFile(modelId)
    return if (file.exists()) {
      (file.length() / (1024 * 1024)).toInt()
    } else 0
  }

  fun deleteModel(modelId: String): Boolean {
    val file = getModelFile(modelId)
    return if (file.exists()) file.delete() else false
  }

  /**
   * Real streaming download from HTTP / HuggingFace to app private storage.
   */
  fun downloadModelFile(model: ModelOption): Flow<Float> = flow {
    val url = model.downloadUrl ?: throw IllegalArgumentException("URL de download ausente")
    val destinationFile = getModelFile(model.id)
    val tempFile = File(modelsDir, "${model.id}.tmp")

    val request = Request.Builder()
      .url(url)
      .header("User-Agent", "PocketPal-Android-ExecuTorch/1.0")
      .build()

    client.newCall(request).execute().use { response ->
      if (!response.isSuccessful) {
        throw IllegalStateException("Falha HTTP ${response.code}: ${response.message}")
      }

      val body = response.body ?: throw IllegalStateException("Corpo da resposta vazio")
      val contentLength = body.contentLength()

      body.byteStream().use { input ->
        FileOutputStream(tempFile).use { output ->
          val buffer = ByteArray(64 * 1024)
          var bytesRead: Int
          var totalBytesRead = 0L
          var lastProgressReport = 0f

          while (input.read(buffer).also { bytesRead = it } != -1) {
            output.write(buffer, 0, bytesRead)
            totalBytesRead += bytesRead

            val currentProgress = if (contentLength > 0) {
              (totalBytesRead.toFloat() / contentLength.toFloat()).coerceIn(0f, 0.99f)
            } else {
              // Fallback if content-length header is not provided
              (totalBytesRead.toFloat() / (model.fileSizeMB * 1024 * 1024).toFloat()).coerceIn(0f, 0.99f)
            }

            // Emit every ~2% progress to avoid flooding the flow
            if (currentProgress - lastProgressReport >= 0.02f) {
              lastProgressReport = currentProgress
              emit(currentProgress)
            }
          }
          output.flush()
        }
      }

      // Rename temp file to final destination
      if (tempFile.exists()) {
        if (destinationFile.exists()) destinationFile.delete()
        tempFile.renameTo(destinationFile)
      }

      emit(1.0f)
    }
  }.flowOn(Dispatchers.IO)

  /**
   * Imports a local file from Content URI (SAF) into app storage.
   */
  suspend fun copyLocalUriToStorage(uri: Uri, modelId: String): File = withContext(Dispatchers.IO) {
    val destinationFile = getModelFile(modelId)
    val tempFile = File(modelsDir, "$modelId.tmp")

    context.contentResolver.openInputStream(uri)?.use { input: InputStream ->
      FileOutputStream(tempFile).use { output ->
        input.copyTo(output, bufferSize = 64 * 1024)
        output.flush()
      }
    } ?: throw IllegalStateException("Não foi possível ler o arquivo selecionado")

    if (tempFile.exists()) {
      if (destinationFile.exists()) destinationFile.delete()
      tempFile.renameTo(destinationFile)
    }

    destinationFile
  }
}
