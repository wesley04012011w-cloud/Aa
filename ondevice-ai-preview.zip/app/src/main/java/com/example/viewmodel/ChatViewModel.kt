package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppScreen
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.ChatUiState
import com.example.model.GenerationStats
import com.example.model.InferenceSettings
import com.example.model.MessageRole
import com.example.model.ModelOption
import com.example.model.PreconfiguredModels
import com.example.service.ModelFileManager
import com.example.service.OnDeviceAiEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel @JvmOverloads constructor(
  application: Application,
  private val engine: OnDeviceAiEngine = OnDeviceAiEngine()
) : AndroidViewModel(application) {

  private val fileManager = ModelFileManager(application)

  private val initialSession = ChatSession(
    id = java.util.UUID.randomUUID().toString(),
    title = "Nova Conversa"
  )

  private val _uiState = MutableStateFlow(
    ChatUiState(
      sessions = listOf(initialSession),
      currentSessionId = initialSession.id
    )
  )
  val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

  private var generationJob: Job? = null
  private var initJob: Job? = null
  private var downloadJob: Job? = null

  init {
    syncDownloadedModelsFromDisk()
  }

  fun syncDownloadedModelsFromDisk() {
    viewModelScope.launch {
      val installedList = _uiState.value.installedModels.map { model ->
        val exists = fileManager.isModelDownloaded(model.id)
        val size = if (exists) fileManager.getModelSizeMB(model.id) else model.fileSizeMB
        model.copy(
          isDownloaded = exists,
          fileSizeMB = if (size > 0) size else model.fileSizeMB,
          localPath = if (exists) fileManager.getModelFile(model.id).absolutePath else null
        )
      }

      val explorerList = _uiState.value.explorerModels.map { model ->
        val exists = fileManager.isModelDownloaded(model.id)
        model.copy(
          isDownloaded = exists,
          localPath = if (exists) fileManager.getModelFile(model.id).absolutePath else null
        )
      }

      val activeDownloaded = installedList.firstOrNull { it.isDownloaded }

      _uiState.update {
        it.copy(
          installedModels = installedList,
          explorerModels = explorerList,
          selectedModel = activeDownloaded
        )
      }

      if (activeDownloaded != null) {
        loadModel(activeDownloaded)
      }
    }
  }

  fun navigateTo(screen: AppScreen) {
    _uiState.update { it.copy(currentScreen = screen) }
  }

  fun loadModel(model: ModelOption) {
    generationJob?.cancel()
    initJob?.cancel()

    initJob = viewModelScope.launch {
      val modelFile = fileManager.getModelFile(model.id)

      _uiState.update {
        it.copy(
          isReady = false,
          initProgress = 0f,
          initStage = "Iniciando ${model.displayName}...",
          initSubtext = "Carregando pesos ExecuTorch .pte (${model.fileSizeMB} MB)...",
          selectedModel = model,
          errorMessage = null
        )
      }

      try {
        engine.initializeModel(model, modelFile).collect { (progress, stage) ->
          _uiState.update {
            it.copy(
              initProgress = progress,
              initStage = stage,
              isReady = progress >= 1.0f
            )
          }
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            errorMessage = "Falha ao carregar modelo: ${e.localizedMessage ?: e.message}"
          )
        }
      }
    }
  }

  fun selectModel(model: ModelOption) {
    if (!model.isDownloaded) {
      downloadModel(model)
      return
    }

    if (model.id == _uiState.value.selectedModel?.id && _uiState.value.isReady) {
      _uiState.update { it.copy(currentScreen = AppScreen.CHAT) }
      return
    }

    _uiState.update { it.copy(currentScreen = AppScreen.CHAT) }
    loadModel(model)
  }

  fun downloadModel(model: ModelOption) {
    downloadJob?.cancel()
    downloadJob = viewModelScope.launch {
      updateModelDownloadState(model.id, isDownloading = true, progress = 0.02f)

      try {
        fileManager.downloadModelFile(model).collect { progress ->
          updateModelDownloadState(model.id, isDownloading = true, progress = progress)
        }

        val downloadedFile = fileManager.getModelFile(model.id)
        val finalSizeMB = fileManager.getModelSizeMB(model.id)

        updateModelDownloadState(
          modelId = model.id,
          isDownloading = false,
          progress = 1.0f,
          isDownloaded = true,
          localPath = downloadedFile.absolutePath,
          fileSizeMB = if (finalSizeMB > 0) finalSizeMB else model.fileSizeMB
        )

        _uiState.update {
          it.copy(
            successMessage = "${model.displayName} baixado e salvo no dispositivo com sucesso!"
          )
        }

        // Auto load newly downloaded model
        val updatedModel = _uiState.value.installedModels.find { it.id == model.id } ?: model
        loadModel(updatedModel)
      } catch (e: Exception) {
        updateModelDownloadState(model.id, isDownloading = false, progress = 0f, isDownloaded = false)
        _uiState.update {
          it.copy(errorMessage = "Erro ao baixar ${model.displayName}: ${e.message}")
        }
      }
    }
  }

  private fun updateModelDownloadState(
    modelId: String,
    isDownloading: Boolean,
    progress: Float,
    isDownloaded: Boolean? = null,
    localPath: String? = null,
    fileSizeMB: Int? = null
  ) {
    _uiState.update { state ->
      val updatedInstalled = state.installedModels.map { m ->
        if (m.id == modelId) {
          m.copy(
            isDownloading = isDownloading,
            downloadProgress = progress,
            isDownloaded = isDownloaded ?: m.isDownloaded,
            localPath = localPath ?: m.localPath,
            fileSizeMB = fileSizeMB ?: m.fileSizeMB
          )
        } else m
      }

      val updatedExplorer = state.explorerModels.map { m ->
        if (m.id == modelId) {
          m.copy(
            isDownloading = isDownloading,
            downloadProgress = progress,
            isDownloaded = isDownloaded ?: m.isDownloaded,
            localPath = localPath ?: m.localPath,
            fileSizeMB = fileSizeMB ?: m.fileSizeMB
          )
        } else m
      }

      var finalInstalled = updatedInstalled
      val downloadedExplorerModel = updatedExplorer.find { it.id == modelId && isDownloaded == true }
      if (downloadedExplorerModel != null && finalInstalled.none { it.id == modelId }) {
        finalInstalled = finalInstalled + downloadedExplorerModel
      }

      state.copy(
        installedModels = finalInstalled,
        explorerModels = updatedExplorer
      )
    }
  }

  fun importLocalModel(fileName: String, uri: Uri, estimatedSizeMB: Int = 500) {
    viewModelScope.launch {
      try {
        val cleanName = fileName.removeSuffix(".pte").removeSuffix(".bin").removeSuffix(".gguf")
        val modelId = "local-pte-${System.currentTimeMillis()}"

        val copiedFile = fileManager.copyLocalUriToStorage(uri, modelId)
        val realSizeMB = fileManager.getModelSizeMB(modelId).let { if (it > 0) it else estimatedSizeMB }

        val importedModel = ModelOption(
          id = modelId,
          displayName = cleanName.ifEmpty { "Modelo Local .pte" },
          family = "ExecuTorch Local",
          parameterCount = "Custom",
          quantization = if (fileName.contains("int4", ignoreCase = true)) "SpinQuant INT4" else "PTE Native",
          fileSizeMB = realSizeMB,
          isDownloaded = true,
          isImported = true,
          localPath = copiedFile.absolutePath,
          author = "Armazenamento Local",
          format = "PTE"
        )

        _uiState.update {
          it.copy(
            installedModels = listOf(importedModel) + it.installedModels,
            successMessage = "Arquivo .pte $fileName importado com sucesso!"
          )
        }

        loadModel(importedModel)
      } catch (e: Exception) {
        _uiState.update {
          it.copy(errorMessage = "Erro ao importar arquivo: ${e.message}")
        }
      }
    }
  }

  fun addCustomHfModel(url: String, customName: String) {
    val trimmedUrl = url.trim()
    if (trimmedUrl.isEmpty()) return

    val detectedName = customName.trim().ifEmpty {
      trimmedUrl.substringAfterLast("/").substringBefore("?").removeSuffix(".pte")
    }

    val newModel = ModelOption(
      id = "hf-pte-${System.currentTimeMillis()}",
      displayName = detectedName,
      family = "ExecuTorch Hub",
      parameterCount = "Custom",
      quantization = "PTE",
      fileSizeMB = 850,
      downloadUrl = trimmedUrl,
      isDownloaded = false,
      author = "Custom URL",
      format = "PTE"
    )

    _uiState.update {
      it.copy(
        installedModels = it.installedModels + newModel,
        successMessage = "Modelo $detectedName adicionado aos downloads!"
      )
    }

    downloadModel(newModel)
  }

  fun deleteModel(modelId: String) {
    viewModelScope.launch {
      fileManager.deleteModel(modelId)
      updateModelDownloadState(modelId, isDownloading = false, progress = 0f, isDownloaded = false, localPath = null)
      if (_uiState.value.selectedModel?.id == modelId) {
        _uiState.update { it.copy(selectedModel = null, isReady = false) }
      }
      _uiState.update { it.copy(successMessage = "Modelo removido do armazenamento") }
    }
  }

  fun updateExplorerSearch(query: String) {
    _uiState.update { it.copy(explorerSearchQuery = query) }
  }

  fun updateCustomHfUrlInput(url: String) {
    _uiState.update { it.copy(customHfUrlInput = url) }
  }

  // Session Management
  fun createNewSession() {
    generationJob?.cancel()
    val newSession = ChatSession(
      id = java.util.UUID.randomUUID().toString(),
      title = "Nova Conversa",
      modelId = _uiState.value.selectedModel?.id ?: ""
    )

    _uiState.update {
      it.copy(
        sessions = listOf(newSession) + it.sessions,
        currentSessionId = newSession.id,
        currentScreen = AppScreen.CHAT,
        isGenerating = false,
        currentStreamingText = "",
        currentStreamingStats = GenerationStats()
      )
    }
  }

  fun selectSession(sessionId: String) {
    generationJob?.cancel()
    _uiState.update {
      it.copy(
        currentSessionId = sessionId,
        currentScreen = AppScreen.CHAT,
        isGenerating = false,
        currentStreamingText = "",
        currentStreamingStats = GenerationStats()
      )
    }
  }

  fun deleteSession(sessionId: String) {
    val currentList = _uiState.value.sessions
    val remaining = currentList.filter { it.id != sessionId }
    val newSessions = if (remaining.isEmpty()) {
      listOf(ChatSession(title = "Nova Conversa", modelId = _uiState.value.selectedModel?.id ?: ""))
    } else remaining

    val nextSessionId = if (sessionId == _uiState.value.currentSessionId) {
      newSessions.first().id
    } else _uiState.value.currentSessionId

    _uiState.update {
      it.copy(
        sessions = newSessions,
        currentSessionId = nextSessionId
      )
    }
  }

  fun renameSession(sessionId: String, newTitle: String) {
    if (newTitle.trim().isEmpty()) return
    _uiState.update { state ->
      val updated = state.sessions.map { s ->
        if (s.id == sessionId) s.copy(title = newTitle.trim()) else s
      }
      state.copy(sessions = updated)
    }
  }

  fun updateSettings(newSettings: InferenceSettings) {
    _uiState.update {
      it.copy(
        settings = newSettings,
        showSettingsSheet = false
      )
    }
  }

  fun sendMessage(inputText: String) {
    val trimmed = inputText.trim()
    val state = _uiState.value
    val model = state.selectedModel

    if (trimmed.isEmpty() || state.isGenerating || !state.isReady || model == null) return

    val userMessage = ChatMessage(
      role = MessageRole.USER,
      content = trimmed,
      timestamp = System.currentTimeMillis()
    )

    val currentSess = state.currentSession
    val updatedMessages = currentSess.messages + userMessage

    val autoTitle = if (currentSess.messages.isEmpty()) {
      trimmed.take(28).let { if (trimmed.length > 28) "$it..." else it }
    } else currentSess.title

    val updatedSession = currentSess.copy(
      title = autoTitle,
      messages = updatedMessages
    )

    _uiState.update { st ->
      st.copy(
        sessions = st.sessions.map { if (it.id == updatedSession.id) updatedSession else it },
        isGenerating = true,
        currentStreamingText = "",
        currentStreamingStats = GenerationStats(),
        errorMessage = null
      )
    }

    generationJob?.cancel()
    generationJob = viewModelScope.launch {
      try {
        var lastStats = GenerationStats()

        engine.generateStreamingResponse(
          userPrompt = trimmed,
          history = updatedMessages,
          model = model,
          settings = state.settings
        ).collect { chunk ->
          lastStats = chunk.stats

          _uiState.update {
            it.copy(
              currentStreamingText = chunk.currentText,
              currentStreamingStats = chunk.stats
            )
          }

          if (chunk.isCompleted) {
            val assistantMessage = ChatMessage(
              role = MessageRole.ASSISTANT,
              content = chunk.currentText,
              timestamp = System.currentTimeMillis(),
              stats = lastStats
            )

            _uiState.update { st ->
              val cur = st.currentSession
              val finalSess = cur.copy(messages = cur.messages + assistantMessage)
              st.copy(
                sessions = st.sessions.map { if (it.id == finalSess.id) finalSess else it },
                isGenerating = false,
                currentStreamingText = "",
                currentStreamingStats = GenerationStats()
              )
            }
          }
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            isGenerating = false,
            errorMessage = "Erro na geração do token: ${e.localizedMessage ?: "Interrompido"}"
          )
        }
      }
    }
  }

  fun stopGeneration() {
    val state = _uiState.value
    if (!state.isGenerating) return

    generationJob?.cancel()
    generationJob = null

    val partialText = state.currentStreamingText.trim()
    if (partialText.isNotEmpty()) {
      val partialMessage = ChatMessage(
        role = MessageRole.ASSISTANT,
        content = "$partialText ⏹️",
        timestamp = System.currentTimeMillis(),
        stats = state.currentStreamingStats
      )
      _uiState.update { st ->
        val cur = st.currentSession
        val finalSess = cur.copy(messages = cur.messages + partialMessage)
        st.copy(
          sessions = st.sessions.map { if (it.id == finalSess.id) finalSess else it },
          isGenerating = false,
          currentStreamingText = "",
          currentStreamingStats = GenerationStats()
        )
      }
    } else {
      _uiState.update {
        it.copy(
          isGenerating = false,
          currentStreamingText = "",
          currentStreamingStats = GenerationStats()
        )
      }
    }
  }

  fun clearCurrentChat() {
    generationJob?.cancel()
    _uiState.update { st ->
      val cur = st.currentSession
      val clearedSess = cur.copy(messages = emptyList())
      st.copy(
        sessions = st.sessions.map { if (it.id == clearedSess.id) clearedSess else it },
        isGenerating = false,
        currentStreamingText = "",
        currentStreamingStats = GenerationStats(),
        errorMessage = null
      )
    }
  }

  fun toggleSettingsSheet(show: Boolean) {
    _uiState.update { it.copy(showSettingsSheet = show) }
  }

  fun toggleHardwareInfoDialog(show: Boolean) {
    _uiState.update { it.copy(showHardwareInfoDialog = show) }
  }

  fun dismissError() {
    _uiState.update { it.copy(errorMessage = null) }
  }

  fun dismissSuccess() {
    _uiState.update { it.copy(successMessage = null) }
  }
}
