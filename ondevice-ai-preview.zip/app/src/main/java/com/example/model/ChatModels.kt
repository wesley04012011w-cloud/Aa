package com.example.model

enum class MessageRole {
  USER,
  ASSISTANT,
  SYSTEM,
}

enum class AppScreen {
  CHAT,
  MODELS,
  EXPLORER,
}

data class GenerationStats(
  val tokensPerSecond: Float = 0f,
  val totalTokens: Int = 0,
  val promptEvalSpeed: Float = 0f,
  val durationMs: Long = 0L,
  val memoryUsedMB: Int = 0,
)

data class ChatMessage(
  val id: String = java.util.UUID.randomUUID().toString(),
  val role: MessageRole,
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val stats: GenerationStats? = null,
)

data class ModelOption(
  val id: String,
  val displayName: String,
  val family: String,
  val parameterCount: String,
  val quantization: String,
  val fileSizeMB: Int,
  val recommendedThreads: Int = 4,
  val contextWindow: Int = 4096,
  val defaultSystemPrompt: String = "Você é um assistente prestativo, inteligente e conciso.",
  val downloadUrl: String? = null,
  val isDownloaded: Boolean = false,
  val isDownloading: Boolean = false,
  val downloadProgress: Float = 0f,
  val isImported: Boolean = false,
  val localPath: String? = null,
  val author: String = "ExecuTorch Hub",
  val hfRepo: String = "",
  val format: String = "PTE",
)

data class InferenceSettings(
  val temperature: Float = 0.7f,
  val topP: Float = 0.9f,
  val topK: Int = 40,
  val maxTokens: Int = 1024,
  val repeatPenalty: Float = 1.1f,
  val cpuThreads: Int = 4,
  val contextWindow: Int = 4096,
  val systemPrompt: String = "Você é um assistente útil e prestativo. Responda sempre em português com clareza.",
)

data class ChatSession(
  val id: String = java.util.UUID.randomUUID().toString(),
  val title: String = "Nova Conversa",
  val createdAt: Long = System.currentTimeMillis(),
  val modelId: String = "llama-3.2-1b-pte",
  val messages: List<ChatMessage> = emptyList(),
)

data class ChatUiState(
  val currentScreen: AppScreen = AppScreen.CHAT,
  val isReady: Boolean = false,
  val initProgress: Float = 0f,
  val initStage: String = "Selecione ou baixe um modelo",
  val initSubtext: String = "Nenhum modelo carregado na memória NDK",
  val selectedModel: ModelOption? = null,
  val installedModels: List<ModelOption> = PreconfiguredModels.ALL_PRECONFIGURED,
  val explorerModels: List<ModelOption> = PreconfiguredModels.EXPLORER_MODELS,
  val settings: InferenceSettings = InferenceSettings(),
  val sessions: List<ChatSession> = listOf(ChatSession()),
  val currentSessionId: String = "",
  val isGenerating: Boolean = false,
  val currentStreamingText: String = "",
  val currentStreamingStats: GenerationStats = GenerationStats(),
  val errorMessage: String? = null,
  val successMessage: String? = null,
  val showSettingsSheet: Boolean = false,
  val showHardwareInfoDialog: Boolean = false,
  val explorerSearchQuery: String = "",
  val customHfUrlInput: String = "",
) {
  val currentSession: ChatSession
    get() = sessions.find { it.id == currentSessionId } ?: sessions.firstOrNull() ?: ChatSession()

  val currentMessages: List<ChatMessage>
    get() = currentSession.messages
}

object PreconfiguredModels {
  // Modelo 1: Llama 3.2 1B PTE (ExecuTorch SpinQuant INT4)
  val LLAMA_3_2_1B_PTE = ModelOption(
    id = "llama-3.2-1b-pte",
    displayName = "Llama 3.2 1B Instruct (.pte)",
    family = "Meta Llama",
    parameterCount = "1.23B",
    quantization = "SpinQuant INT4",
    fileSizeMB = 790,
    recommendedThreads = 4,
    contextWindow = 4096,
    defaultSystemPrompt = "Você é o Llama 3.2, assistente de IA on-device rodando nativamente via ExecuTorch.",
    downloadUrl = "https://huggingface.co/pytorch/executorch-models/resolve/main/llama3_2_1b_instruct_spinquant.pte?download=true",
    isDownloaded = false,
    author = "PyTorch ExecuTorch",
    hfRepo = "pytorch/executorch-models",
    format = "PTE"
  )

  // Modelo 2: Qwen 2.5 1.5B PTE
  val QWEN_2_5_PTE = ModelOption(
    id = "qwen-2.5-1.5b-pte",
    displayName = "Qwen 2.5 1.5B Instruct (.pte)",
    family = "Alibaba Qwen",
    parameterCount = "1.54B",
    quantization = "XNNPACK INT4",
    fileSizeMB = 890,
    recommendedThreads = 4,
    contextWindow = 4096,
    defaultSystemPrompt = "Você é o Qwen 2.5, modelo rápido e avançado para raciocínio e tarefas gerais.",
    downloadUrl = "https://huggingface.co/pytorch/executorch-models/resolve/main/qwen2_5_1_5b_instruct.pte?download=true",
    isDownloaded = false,
    author = "Qwen / ExecuTorch",
    hfRepo = "pytorch/executorch-models",
    format = "PTE"
  )

  // Modelo 3: Gemma 2 2B PTE
  val GEMMA_2_2B_PTE = ModelOption(
    id = "gemma-2-2b-pte",
    displayName = "Gemma 2 2B IT (.pte)",
    family = "Google Gemma",
    parameterCount = "2.61B",
    quantization = "XNNPACK W4A16",
    fileSizeMB = 1350,
    recommendedThreads = 6,
    contextWindow = 8192,
    defaultSystemPrompt = "Você é o Gemma 2, assistente com alto raciocínio da Google.",
    downloadUrl = "https://huggingface.co/pytorch/executorch-models/resolve/main/gemma2_2b_it_xnnpack.pte?download=true",
    isDownloaded = false,
    author = "Google / ExecuTorch",
    hfRepo = "pytorch/executorch-models",
    format = "PTE"
  )

  val ALL_PRECONFIGURED = listOf(
    LLAMA_3_2_1B_PTE,
    QWEN_2_5_PTE,
    GEMMA_2_2B_PTE
  )

  val EXPLORER_MODELS = listOf(
    ModelOption(
      id = "smollm2-1.7b-pte",
      displayName = "SmolLM2 1.7B Instruct (.pte)",
      family = "HuggingFace",
      parameterCount = "1.71B",
      quantization = "INT4 SpinQuant",
      fileSizeMB = 920,
      recommendedThreads = 4,
      contextWindow = 4096,
      defaultSystemPrompt = "Você é o SmolLM2, assistente ultrarrápido para Android.",
      downloadUrl = "https://huggingface.co/pytorch/executorch-models/resolve/main/smollm2_1_7b_instruct.pte?download=true",
      author = "HuggingFaceTB",
      hfRepo = "pytorch/executorch-models",
      format = "PTE"
    ),
    ModelOption(
      id = "deepseek-r1-1.5b-pte",
      displayName = "DeepSeek R1 1.5B Distill (.pte)",
      family = "DeepSeek AI",
      parameterCount = "1.5B",
      quantization = "INT4 QNN / CPU",
      fileSizeMB = 950,
      recommendedThreads = 4,
      contextWindow = 8192,
      defaultSystemPrompt = "Você é o DeepSeek R1, modelo focado em raciocínio lógico e matemático.",
      downloadUrl = "https://huggingface.co/pytorch/executorch-models/resolve/main/deepseek_r1_1_5b_qnn.pte?download=true",
      author = "DeepSeek AI",
      hfRepo = "pytorch/executorch-models",
      format = "PTE"
    ),
    ModelOption(
      id = "phi-3.5-mini-pte",
      displayName = "Phi-3.5 Mini Instruct (.pte)",
      family = "Microsoft Phi",
      parameterCount = "3.82B",
      quantization = "INT4 XNNPACK",
      fileSizeMB = 1680,
      recommendedThreads = 6,
      contextWindow = 8192,
      defaultSystemPrompt = "Você é o Phi-3.5 Mini, modelo avançado de raciocínio da Microsoft.",
      downloadUrl = "https://huggingface.co/pytorch/executorch-models/resolve/main/phi_3_5_mini_instruct.pte?download=true",
      author = "Microsoft / ExecuTorch",
      hfRepo = "pytorch/executorch-models",
      format = "PTE"
    )
  )
}
