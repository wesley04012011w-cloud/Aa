package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppScreen
import com.example.model.ChatMessage
import com.example.model.ChatUiState
import com.example.model.GenerationStats
import com.example.model.InferenceSettings
import com.example.model.MessageRole
import com.example.model.ModelOption
import com.example.ui.theme.AssistantBubbleDark
import com.example.ui.theme.AssistantBubbleLight
import com.example.ui.theme.UserBubbleDark
import com.example.ui.theme.UserBubbleLight
import com.example.viewmodel.ChatViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
  viewModel: ChatViewModel,
  onOpenDrawer: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val listState = rememberLazyListState()
  var inputMessage by remember { mutableStateOf("") }
  val snackbarHostState = remember { SnackbarHostState() }
  var showMenu by remember { mutableStateOf(false) }

  // Auto-scroll on new message or while streaming
  LaunchedEffect(uiState.currentMessages.size, uiState.currentStreamingText.isNotEmpty()) {
    val totalItems = uiState.currentMessages.size + if (uiState.isGenerating) 1 else 0
    if (totalItems > 0) {
      listState.animateScrollToItem(totalItems - 1)
    }
  }

  LaunchedEffect(uiState.errorMessage) {
    uiState.errorMessage?.let { errorMsg ->
      snackbarHostState.showSnackbar(errorMsg)
      viewModel.dismissError()
    }
  }

  LaunchedEffect(uiState.successMessage) {
    uiState.successMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.dismissSuccess()
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    contentWindowInsets = WindowInsets.statusBars,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          titleContentColor = MaterialTheme.colorScheme.onSurface
        ),
        navigationIcon = {
          IconButton(
            onClick = onOpenDrawer,
            modifier = Modifier.testTag("open_drawer_button")
          ) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = "Menu Lateral",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }
        },
        title = {
          // Model Selection Pill
          Surface(
            onClick = { viewModel.navigateTo(AppScreen.MODELS) },
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            modifier = Modifier.testTag("model_selector_trigger")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (uiState.isReady) Color(0xFFFFFFFF) else Color(0xFF71717A))
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = uiState.selectedModel?.displayName ?: "Nenhum modelo",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 160.dp),
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "Trocar modelo",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                Text(
                  text = if (uiState.selectedModel != null) {
                    "${uiState.selectedModel!!.quantization} • ${uiState.selectedModel!!.fileSizeMB} MB"
                  } else {
                    "Toque para baixar"
                  },
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        },
        actions = {
          IconButton(
            onClick = { viewModel.navigateTo(AppScreen.MODELS) },
            modifier = Modifier.testTag("top_models_button")
          ) {
            Icon(
              imageVector = Icons.Default.CloudDownload,
              contentDescription = "Modelos & Downloads",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(
            onClick = { viewModel.toggleSettingsSheet(true) },
            modifier = Modifier.testTag("settings_button")
          ) {
            Icon(
              imageVector = Icons.Default.Tune,
              contentDescription = "Parâmetros de Inferência",
              tint = MaterialTheme.colorScheme.onSurface
            )
          }

          Box {
            IconButton(
              onClick = { showMenu = true },
              modifier = Modifier.testTag("overflow_menu_button")
            ) {
              Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "Mais opções",
                tint = MaterialTheme.colorScheme.onSurface
              )
            }

            DropdownMenu(
              expanded = showMenu,
              onDismissRequest = { showMenu = false }
            ) {
              DropdownMenuItem(
                text = { Text("Informações de Hardware / NDK") },
                leadingIcon = { Icon(Icons.Default.Memory, contentDescription = null) },
                onClick = {
                  showMenu = false
                  viewModel.toggleHardwareInfoDialog(true)
                }
              )
              DropdownMenuItem(
                text = { Text("Recarregar Modelo") },
                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) },
                onClick = {
                  showMenu = false
                  uiState.selectedModel?.let { viewModel.loadModel(it) }
                }
              )
              if (uiState.currentMessages.isNotEmpty()) {
                HorizontalDivider()
                DropdownMenuItem(
                  text = { Text("Limpar Conversa Atual", color = MaterialTheme.colorScheme.error) },
                  leadingIcon = {
                    Icon(
                      Icons.Default.DeleteOutline,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.error
                    )
                  },
                  onClick = {
                    showMenu = false
                    viewModel.clearCurrentChat()
                  }
                )
              }
            }
          }
        }
      )
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(top = innerPadding.calculateTopPadding())
        .background(MaterialTheme.colorScheme.background)
    ) {
      if (uiState.selectedModel == null) {
        // No Model Downloaded State
        NoModelDownloadedView(
          onGoToModels = { viewModel.navigateTo(AppScreen.MODELS) },
          onDownloadFirst = {
            val first = uiState.installedModels.firstOrNull()
            if (first != null) viewModel.downloadModel(first)
          },
          modifier = Modifier.weight(1f)
        )
      } else if (!uiState.isReady) {
        LoadingStateView(
          uiState = uiState,
          onRetry = { uiState.selectedModel?.let { viewModel.loadModel(it) } },
          modifier = Modifier.weight(1f)
        )
      } else {
        // Chat Content Area
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          if (uiState.currentMessages.isEmpty() && !uiState.isGenerating) {
            PocketPalEmptyState(
              selectedModel = uiState.selectedModel!!,
              onSelectSuggestion = { suggestion ->
                viewModel.sendMessage(suggestion)
              }
            )
          } else {
            LazyColumn(
              state = listState,
              modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
              contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp),
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              itemsIndexed(
                items = uiState.currentMessages,
                key = { _, msg -> msg.id }
              ) { _, message ->
                GrayChatMessageBubble(
                  message = message,
                  onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("PocketPal", message.content)
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(context, "Copiado", Toast.LENGTH_SHORT).show()
                  }
                )
              }

              if (uiState.isGenerating) {
                item(key = "generating_stream_item") {
                  StreamingResponseCard(
                    streamingText = uiState.currentStreamingText,
                    stats = uiState.currentStreamingStats
                  )
                }
              }
            }
          }
        }

        // PocketPal Input Bar
        PocketPalInputBar(
          inputText = inputMessage,
          onInputChange = { inputMessage = it },
          isGenerating = uiState.isGenerating,
          isReady = uiState.isReady,
          modelName = uiState.selectedModel?.displayName ?: "",
          onSend = {
            val toSend = inputMessage
            inputMessage = ""
            viewModel.sendMessage(toSend)
          },
          onStop = {
            viewModel.stopGeneration()
          }
        )
      }
    }
  }

  // Inference Settings Bottom Sheet
  if (uiState.showSettingsSheet) {
    InferenceSettingsBottomSheet(
      currentSettings = uiState.settings,
      onSave = { newSettings -> viewModel.updateSettings(newSettings) },
      onDismiss = { viewModel.toggleSettingsSheet(false) }
    )
  }

  // Hardware & NDK Info Dialog
  if (uiState.showHardwareInfoDialog) {
    HardwareInfoDialog(
      uiState = uiState,
      onDismiss = { viewModel.toggleHardwareInfoDialog(false) }
    )
  }
}

@Composable
fun NoModelDownloadedView(
  onGoToModels: () -> Unit,
  onDownloadFirst: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(76.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.surfaceVariant),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.CloudDownload,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.size(40.dp)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Nenhum Modelo Instalado",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = "Baixe um modelo .pte pré-configurado ou importe do seu armazenamento para iniciar o chat on-device.",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(24.dp))

    Button(
      onClick = onGoToModels,
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary
      )
    ) {
      Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text("Ver Lista de Modelos")
    }
  }
}

@Composable
fun PocketPalInputBar(
  inputText: String,
  onInputChange: (String) -> Unit,
  isGenerating: Boolean,
  isReady: Boolean,
  modelName: String,
  onSend: () -> Unit,
  onStop: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .imePadding()
      .navigationBarsPadding(),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    shadowElevation = 4.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant)
          .border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(24.dp)
          )
          .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        BasicTextField(
          value = inputText,
          onValueChange = onInputChange,
          enabled = isReady && !isGenerating,
          textStyle = MaterialTheme.typography.bodyMedium.copy(
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 15.sp,
            lineHeight = 20.sp
          ),
          cursorBrush = SolidColor(MaterialTheme.colorScheme.onSurface),
          maxLines = 5,
          minLines = 1,
          modifier = Modifier
            .weight(1f)
            .padding(vertical = 6.dp)
            .testTag("chat_input"),
          decorationBox = { innerTextField ->
            Box(
              contentAlignment = Alignment.CenterStart,
              modifier = Modifier.fillMaxWidth()
            ) {
              if (inputText.isEmpty()) {
                Text(
                  text = if (isGenerating) "Gerando resposta..." else "Mensagem para IA...",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                  fontSize = 14.sp
                )
              }
              innerTextField()
            }
          }
        )

        Spacer(modifier = Modifier.width(8.dp))

        AnimatedContent(
          targetState = isGenerating,
          transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(150)) },
          label = "SendStopButton"
        ) { generating ->
          if (generating) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.error)
                .clickable { onStop() }
                .testTag("stop_generation_button"),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "Parar geração",
                tint = MaterialTheme.colorScheme.onError,
                modifier = Modifier.size(18.dp)
              )
            }
          } else {
            val canSend = inputText.trim().isNotEmpty() && isReady
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (canSend) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                .clickable(enabled = canSend) { onSend() }
                .testTag("send_button"),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = "Enviar",
                tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun GrayChatMessageBubble(
  message: ChatMessage,
  onCopy: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isUser = message.role == MessageRole.USER
  val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
  val formattedTime = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }

  val bubbleColor = if (isUser) {
    MaterialTheme.colorScheme.surfaceVariant
  } else {
    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .testTag("message_${message.id}"),
    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
      Text(
        text = if (isUser) "Você" else "PocketPal AI",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = formattedTime,
        style = MaterialTheme.typography.labelSmall,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
      )
    }

    Card(
      shape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (isUser) 18.dp else 4.dp,
        bottomEnd = if (isUser) 4.dp else 18.dp
      ),
      colors = CardDefaults.cardColors(containerColor = bubbleColor),
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
      modifier = Modifier.widthIn(max = 330.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        FormattedChatText(
          content = message.content,
          isUser = isUser
        )

        if (!isUser) {
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            if (message.stats != null && message.stats.tokensPerSecond > 0) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.Bolt,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.onSurface,
                      modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                      text = String.format(Locale.getDefault(), "%.1f tok/s", message.stats.tokensPerSecond),
                      style = MaterialTheme.typography.labelSmall,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }

                Text(
                  text = "${message.stats.totalTokens} tok • ${message.stats.durationMs / 1000f}s",
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 10.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
              }
            } else {
              Spacer(modifier = Modifier.width(1.dp))
            }

            IconButton(
              onClick = onCopy,
              modifier = Modifier.size(24.dp)
            ) {
              Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = "Copiar",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                modifier = Modifier.size(14.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun FormattedChatText(
  content: String,
  isUser: Boolean
) {
  val context = LocalContext.current

  if (content.contains("```")) {
    val parts = content.split("```")
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      parts.forEachIndexed { index, part ->
        if (index % 2 == 1) {
          val lines = part.trim().lines()
          val lang = if (lines.firstOrNull()?.matches(Regex("^[a-zA-Z0-9]+$")) == true) lines.first() else ""
          val codeText = if (lang.isNotEmpty()) lines.drop(1).joinToString("\n") else part.trim()

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              if (lang.isNotEmpty()) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = lang.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                  )
                  Text(
                    text = "Copiar",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 10.sp,
                    modifier = Modifier.clickable {
                      val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                      clipboard.setPrimaryClip(ClipData.newPlainText("Código", codeText))
                      Toast.makeText(context, "Código copiado", Toast.LENGTH_SHORT).show()
                    }
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
              }
              Text(
                text = codeText,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        } else if (part.isNotBlank()) {
          Text(
            text = part.trim(),
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }
  } else {
    Text(
      text = content,
      style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
      color = MaterialTheme.colorScheme.onSurface
    )
  }
}

@Composable
fun StreamingResponseCard(
  streamingText: String,
  stats: GenerationStats,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.Start
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
      Text(
        text = "PocketPal AI",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.width(6.dp))
      if (stats.tokensPerSecond > 0) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = MaterialTheme.colorScheme.surfaceVariant
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Bolt,
              contentDescription = null,
              modifier = Modifier.size(10.dp),
              tint = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = String.format(Locale.getDefault(), "%.1f tok/s", stats.tokensPerSecond),
              style = MaterialTheme.typography.labelSmall,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    Card(
      shape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = 4.dp,
        bottomEnd = 18.dp
      ),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
      border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
      modifier = Modifier.widthIn(max = 330.dp)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        if (streamingText.isEmpty()) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(14.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "Avaliando prompt no runtime ExecuTorch...",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontStyle = FontStyle.Italic,
              fontSize = 13.sp
            )
          }
        } else {
          Text(
            text = streamingText,
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PocketPalEmptyState(
  selectedModel: ModelOption,
  onSelectSuggestion: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val suggestions = listOf(
    "O que é ExecuTorch e On-Device AI?",
    "Escreva um código Kotlin nativo NDK",
    "Quais as vantagens de rodar LLM localmente?",
    "Crie um roteiro de viagem de 3 dias",
    "Como funciona a quantização SpinQuant INT4?"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(64.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.surfaceVariant),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.SmartToy,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.size(36.dp)
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = selectedModel.displayName,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = "Inferência ExecuTorch .pte 100% offline no dispositivo",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = "Sugestões de comandos:",
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(10.dp))

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      suggestions.forEach { suggestion ->
        FilterChip(
          selected = false,
          onClick = { onSelectSuggestion(suggestion) },
          label = {
            Text(
              text = suggestion,
              style = MaterialTheme.typography.bodySmall,
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
          },
          colors = FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            labelColor = MaterialTheme.colorScheme.onSurface
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = false,
            borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
          ),
          shape = RoundedCornerShape(14.dp)
        )
      }
    }
  }
}

@Composable
fun LoadingStateView(
  uiState: ChatUiState,
  onRetry: () -> Unit,
  modifier: Modifier = Modifier
) {
  val modelName = uiState.selectedModel?.displayName ?: "Modelo"

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(76.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.surfaceVariant),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Memory,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.size(40.dp)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = modelName,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = uiState.initSubtext,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(20.dp))

    LinearProgressIndicator(
      progress = { uiState.initProgress },
      modifier = Modifier
        .fillMaxWidth(0.8f)
        .height(6.dp)
        .clip(RoundedCornerShape(3.dp)),
      color = MaterialTheme.colorScheme.primary,
      trackColor = MaterialTheme.colorScheme.surfaceVariant
    )

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = uiState.initStage,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurface,
      fontWeight = FontWeight.Medium
    )

    if (uiState.errorMessage != null) {
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = uiState.errorMessage,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.error,
        textAlign = TextAlign.Center
      )
      Spacer(modifier = Modifier.height(10.dp))
      Button(onClick = onRetry) {
        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Tentar Novamente")
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InferenceSettingsBottomSheet(
  currentSettings: InferenceSettings,
  onSave: (InferenceSettings) -> Unit,
  onDismiss: () -> Unit
) {
  var temperature by remember { mutableFloatStateOf(currentSettings.temperature) }
  var topP by remember { mutableFloatStateOf(currentSettings.topP) }
  var cpuThreads by remember { mutableIntStateOf(currentSettings.cpuThreads) }
  var maxTokens by remember { mutableIntStateOf(currentSettings.maxTokens) }
  var systemPrompt by remember { mutableStateOf(currentSettings.systemPrompt) }

  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 12.dp)
        .verticalScroll(rememberScrollState())
        .navigationBarsPadding()
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Parâmetros de Inferência ExecuTorch",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        TextButton(
          onClick = {
            onSave(
              currentSettings.copy(
                temperature = temperature,
                topP = topP,
                cpuThreads = cpuThreads,
                maxTokens = maxTokens,
                systemPrompt = systemPrompt
              )
            )
          }
        ) {
          Text("Salvar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("Temperature (Criatividade)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
        Text(String.format(Locale.getDefault(), "%.2f", temperature), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
      }
      Slider(
        value = temperature,
        onValueChange = { temperature = it },
        valueRange = 0.0f..1.5f,
        steps = 14
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("Top-P (Nucleus Sampling)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
        Text(String.format(Locale.getDefault(), "%.2f", topP), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
      }
      Slider(
        value = topP,
        onValueChange = { topP = it },
        valueRange = 0.1f..1.0f,
        steps = 8
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("Threads NDK (CPU/NPU)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
        Text("$cpuThreads threads", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
      }
      Slider(
        value = cpuThreads.toFloat(),
        onValueChange = { cpuThreads = it.toInt() },
        valueRange = 1f..8f,
        steps = 6
      )

      Spacer(modifier = Modifier.height(12.dp))

      Text("System Prompt", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = systemPrompt,
        onValueChange = { systemPrompt = it },
        modifier = Modifier.fillMaxWidth(),
        maxLines = 4,
        shape = RoundedCornerShape(12.dp),
        textStyle = MaterialTheme.typography.bodySmall
      )

      Spacer(modifier = Modifier.height(20.dp))
    }
  }
}

@Composable
fun HardwareInfoDialog(
  uiState: ChatUiState,
  onDismiss: () -> Unit
) {
  val runtime = Runtime.getRuntime()
  val maxMemoryMB = (runtime.maxMemory() / (1024 * 1024)).toInt()
  val allocatedMemoryMB = (runtime.totalMemory() / (1024 * 1024)).toInt()
  val freeMemoryMB = (runtime.freeMemory() / (1024 * 1024)).toInt()
  val availableCores = runtime.availableProcessors()
  val model = uiState.selectedModel

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Hardware & ExecuTorch NDK", style = MaterialTheme.typography.titleMedium)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        InfoDialogRow("Processador (Cores)", "$availableCores núcleos disponíveis")
        InfoDialogRow("Threads Ativas NDK", "${uiState.settings.cpuThreads} threads")
        InfoDialogRow("Memória JVM Máxima", "$maxMemoryMB MB")
        InfoDialogRow("Memória Alocada", "$allocatedMemoryMB MB")
        InfoDialogRow("Memória Livre", "$freeMemoryMB MB")
        InfoDialogRow("Modelo Atual", model?.displayName ?: "Nenhum carregado")
        InfoDialogRow("Formato de Pesos", model?.format ?: "PTE")
        InfoDialogRow("Tamanho do Modelo", if (model != null) "${model.fileSizeMB} MB" else "-")
        InfoDialogRow("Quantização", model?.quantization ?: "-")
        InfoDialogRow("Context Window", if (model != null) "${model.contextWindow} tokens" else "-")
        InfoDialogRow("Caminho Local", model?.localPath ?: "Memória temporária")
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("Fechar", color = MaterialTheme.colorScheme.onSurface)
      }
    }
  )
}

@Composable
fun InfoDialogRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurface,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.widthIn(max = 180.dp)
    )
  }
}
