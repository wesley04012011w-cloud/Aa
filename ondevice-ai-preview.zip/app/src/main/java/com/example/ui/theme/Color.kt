package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Monochromatic Minimalist Palette (All accents White / Gray, No random bright colors)
val PrimaryLight = Color(0xFF18181B)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFE4E4E7)
val OnPrimaryContainerLight = Color(0xFF18181B)

val PrimaryDark = Color(0xFFFFFFFF)
val OnPrimaryDark = Color(0xFF18181B)
val PrimaryContainerDark = Color(0xFF27272A)
val OnPrimaryContainerDark = Color(0xFFFFFFFF)

// Monochromatic Secondary
val SecondaryLight = Color(0xFF3F3F46)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFF4F4F5)
val OnSecondaryContainerLight = Color(0xFF18181B)

val SecondaryDark = Color(0xFFE4E4E7)
val OnSecondaryDark = Color(0xFF18181B)
val SecondaryContainerDark = Color(0xFF27272A)
val OnSecondaryContainerDark = Color(0xFFE4E4E7)

// Background & Surfaces (Clean Charcoal / Pure Dark & Crisp Off-White)
val BackgroundLight = Color(0xFFF4F4F5)
val OnBackgroundLight = Color(0xFF18181B)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF18181B)
val SurfaceVariantLight = Color(0xFFE4E4E7)
val OnSurfaceVariantLight = Color(0xFF52525B)

val BackgroundDark = Color(0xFF0D0D10)
val OnBackgroundDark = Color(0xFFF4F4F5)
val SurfaceDark = Color(0xFF151518)
val OnSurfaceDark = Color(0xFFF4F4F5)
val SurfaceVariantDark = Color(0xFF202024)
val OnSurfaceVariantDark = Color(0xFFA1A1AA)

// Chat Bubbles (Both User and Assistant are GRAY as strictly requested)
val UserBubbleLight = Color(0xFFD4D4D8)
val UserBubbleTextLight = Color(0xFF18181B)
val AssistantBubbleLight = Color(0xFFE4E4E7)
val AssistantBubbleTextLight = Color(0xFF18181B)

val UserBubbleDark = Color(0xFF2E2E33)
val UserBubbleTextDark = Color(0xFFF4F4F5)
val AssistantBubbleDark = Color(0xFF222226)
val AssistantBubbleTextDark = Color(0xFFE4E4E7)

// Pure Neutral Status Colors
val NeutralBorderDark = Color(0xFF333338)
val NeutralBorderLight = Color(0xFFE4E4E7)
val NeutralBadge = Color(0xFF27272A)
val ErrorRed = Color(0xFFEF4444)
