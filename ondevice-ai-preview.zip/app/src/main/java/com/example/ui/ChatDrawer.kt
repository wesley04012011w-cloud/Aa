package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppScreen
import com.example.model.ChatSession
import com.example.model.ChatUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatNavigationDrawerContent(
  uiState: ChatUiState,
  onNavigate: (AppScreen) -> Unit,
  onNewChat: () -> Unit,
  onSelectSession: (String) -> Unit,
  onDeleteSession: (String) -> Unit,
  onOpenSettings: () -> Unit,
  onOpenHardwareInfo: () -> Unit,
  onCloseDrawer: () -> Unit,
  modifier: Modifier = Modifier
) {
  val dateFormat = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())

  ModalDrawerSheet(
    modifier = modifier
      .fillMaxHeight()
      .width(310.dp),
    drawerContainerColor = MaterialTheme.colorScheme.surface,
    drawerContentColor = MaterialTheme.colorScheme.onSurface
  ) {
    Column(
      modifier = Modifier
        .fillMaxHeight()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      // Header
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.SmartToy,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "PocketPal AI",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "On-Device LLM Runtime",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // New Chat Button
      Surface(
        onClick = {
          onNewChat()
          onCloseDrawer()
        },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("drawer_new_chat_button")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Novo Chat",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Novo Chat",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Navigation Options (Modelos & Explorer)
      DrawerNavItem(
        icon = Icons.Default.CloudDownload,
        label = "Modelos & Downloads",
        badge = "${uiState.installedModels.size}",
        isSelected = uiState.currentScreen == AppScreen.MODELS,
        onClick = {
          onNavigate(AppScreen.MODELS)
          onCloseDrawer()
        },
        testTag = "drawer_nav_models"
      )

      DrawerNavItem(
        icon = Icons.Default.Explore,
        label = "HuggingFace Explorer",
        isSelected = uiState.currentScreen == AppScreen.EXPLORER,
        onClick = {
          onNavigate(AppScreen.EXPLORER)
          onCloseDrawer()
        },
        testTag = "drawer_nav_explorer"
      )

      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "CONVERSAS SALVAS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
      )

      // Saved chats list
      LazyColumn(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        items(uiState.sessions, key = { it.id }) { session ->
          val isCurrent = session.id == uiState.currentSessionId && uiState.currentScreen == AppScreen.CHAT
          SessionListItem(
            session = session,
            isCurrent = isCurrent,
            formattedDate = dateFormat.format(Date(session.createdAt)),
            onSelect = {
              onSelectSession(session.id)
              onCloseDrawer()
            },
            onDelete = {
              onDeleteSession(session.id)
            }
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
      Spacer(modifier = Modifier.height(8.dp))

      // Footer actions (Settings & Hardware Info)
      DrawerNavItem(
        icon = Icons.Default.Tune,
        label = "Parâmetros de Inferência",
        isSelected = false,
        onClick = {
          onOpenSettings()
          onCloseDrawer()
        },
        testTag = "drawer_nav_settings"
      )

      DrawerNavItem(
        icon = Icons.Default.Memory,
        label = "Status do Hardware / NDK",
        isSelected = false,
        onClick = {
          onOpenHardwareInfo()
          onCloseDrawer()
        },
        testTag = "drawer_nav_hardware"
      )
    }
  }
}

@Composable
fun DrawerNavItem(
  icon: ImageVector,
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  badge: String? = null,
  testTag: String = ""
) {
  val backgroundColor = if (isSelected) {
    MaterialTheme.colorScheme.surfaceVariant
  } else {
    Color.Transparent
  }

  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(10.dp),
    color = backgroundColor,
    modifier = modifier
      .fillMaxWidth()
      .testTag(testTag)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.weight(1f)
      )
      if (badge != null) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = MaterialTheme.colorScheme.surfaceVariant
        ) {
          Text(
            text = badge,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }
    }
  }
}

@Composable
fun SessionListItem(
  session: ChatSession,
  isCurrent: Boolean,
  formattedDate: String,
  onSelect: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    onClick = onSelect,
    shape = RoundedCornerShape(10.dp),
    color = if (isCurrent) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Default.ChatBubbleOutline,
        contentDescription = null,
        tint = if (isCurrent) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = session.title,
          style = MaterialTheme.typography.bodySmall,
          fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "${session.messages.size} msgs • $formattedDate",
          style = MaterialTheme.typography.labelSmall,
          fontSize = 9.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
      }
      IconButton(
        onClick = onDelete,
        modifier = Modifier.size(24.dp)
      ) {
        Icon(
          imageVector = Icons.Default.DeleteOutline,
          contentDescription = "Excluir",
          tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.size(14.dp)
        )
      }
    }
  }
}
